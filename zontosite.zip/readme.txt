Привет! Спасибо за просмотр, если используешь это - 
не удаляй этот файл! Пускай он тут лежит, в обмен 
на бесплатное использование =3

👓Посмотреть сайт: https://zonto.site/results/01
📁Сайт можно скачать тут: https://github.com/zontoed/WordoSite
______________________
💸 Задонатить: https://donate.qiwi.com/payin/zontoedik
✨Мой Discord: !迪克 • zontoedik#7007
🎥 Мой Telegram: https://t.me/zontodev
📱 Мой ВК: https://vk.com/zontoedik
💻 Мой GitHub: https://github.com/zontoed
